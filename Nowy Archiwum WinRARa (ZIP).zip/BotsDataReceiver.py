class BotsDataReceiver:
    def __init__(self):
        pass
    def receive_packets(self, socket):
        bots