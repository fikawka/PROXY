from enum import Enum

from bot.Bots import Bots


class Bot:
    def __init__(self, id, owner, socket, nick):
        self.id = id
        self.owner = owner
        self.socket = socket
        self.nick = nick
        self.bot_states = BotState()
        self.bot_state = self.bot_states.HANDSHAKE

        Bots.all_bots.append(self)
class BotState(Enum):
    HANDSHAKE = 1
    LOGIN = 2
    PLAY = 3


