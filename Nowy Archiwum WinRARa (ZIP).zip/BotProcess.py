class BotProcess:
    _instance = None
