import socket
import threading

from bot import BotUtils
from bot.Bot import Bot
from bot.BotsDataReceiver import BotsDataReceiver
from bot.BotsDataSender import BotsDataSender
from server_packets.ChatMessagePacket import ChatMessagePacket


class Bots:
    all_bots = [{}]
    def __init__(self, owner):
        self.owner = owner
        self.bots = None
        self.data_receiver = BotsDataReceiver()
        self.bots_sender = BotsDataSender()

    def connectBots(self, bot_count: int, proxy: bool, ip, port: int, nick):
        thread = threading.Thread(target=self.startSockets, args=(bot_count, proxy, ip, port, nick))
        thread.daemon = True
        thread.start()


    def startSockets(self, bot_count, proxy: bool, ip, port: int, nick:str):
        nick_nr = 0
        for i in range(bot_count):
            sockets = []
            sockets.append(socket.socket(socket.AF_INET, socket.SOCK_STREAM))
            try:
                sockets[i].connect((ip, port))
                bot = Bot(id=BotUtils.generateId(), owner=self.owner, socket = sockets[i], nick=nick_nr)
                nick_nr += 1
                self.bots.append(bot)
            except Exception as e:
                self.owner.sendPacket(ChatMessagePacket(message=f"Błąd podczas łączenia bota: {str(e)}", sender=None, color="red",bold=True))
            self.bots_sender.sendData(bots=self.bots)
            self.data_receiver.receive_packets(sockets)
