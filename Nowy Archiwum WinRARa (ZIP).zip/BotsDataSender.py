import queue


class BotsDataSender:
    def __init__(self):
        self.kolejka_do_wyslania = queue.Queue()
    def sendData(self, bots):



